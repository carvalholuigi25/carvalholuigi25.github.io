<!doctype html>
<html lang="en">
  <head>
    <base href="/">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>LCP Email Sender</title>
    <link href="assets/frameworks/bootstrap-5.2.3/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/icons/bootstrap-icons-1.10.2/bootstrap-icons.css" rel="stylesheet">
    <link href="styles.css" rel="stylesheet">
  </head>
  <body>
    <div class="container">
        <div class="row centered">
            <div class="col-12">
                <h1>LCP Email Sender</h1>
                <?php 
                    if(isset($_POST["send"])) {
                        $to = $_POST["to"];
                        $subject = $_POST["subject"];
                        $message = $_POST["message"] . "\r\n" . "Sended by: " . $_POST["firstname"] . " " . $_POST["lastname"];
                        $headers = 'From: '.$_POST["from"]."\r\n".
                        'Reply-To: '.$_POST["to"]."\r\n".
                        'X-Mailer: PHP/' . phpversion();
                    
                        $m = mail($to, $subject, $message, $headers);
                        
                        if($m) {
                            echo "<i class='ico bi bi-check-circle-fill'></i>";
                            echo "<p class='msg'>Success: Your mail has been sended to " . $_POST["to"] . "!</p>";
                        } else {
                            echo "<i class='ico bi bi-exclamation-circle-fill'></i>";
                            echo "<p class='msg'>Error: Your mail has failed to send " . $_POST["to"] . "! Please try it again later or contact the <a href='mailto:carvalholuigi25@gmail.com'>administrator</a> of this website.</p>";
                        }
                        
                        echo "<a href='index.php' class='btn btn-primary mt-3 mb-3'>Back to home</a>";
                    } else {
                        echo '
                        <form action="index.php" method="post">
                            <input type="hidden" name="to" value="carvalholuigi25@gmail.com" style="width: 100%;" />
                            <br />
                            <label for="firstname">First Name</label><br>
                            <input type="text" name="firstname" value="" placeholder="Write your first name here" style="width: 100%;" />
                            <br /><br />
                            <label for="lastname">Last Name</label><br>
                            <input type="text" name="lastname" value="" placeholder="Write your last name here" style="width: 100%;" />
                            <br /><br />
                            <label for="from">Email</label><br>
                            <input type="email" name="from" value="" placeholder="Write your email here" style="width: 100%;" />
                            <br /><br />
                            <label for="subject">Subject</label><br>
                            <input type="text" name="subject" value="" placeholder="Write any subject you want here" style="width: 100%;" />
                            <br /><br />
                            <label for="message">Message</label><br>
                            <textarea name="message" placeholder="Write any message you want here" cols="1" rows="10" style="width: 100%;"></textarea>
                            <br /><br />
                            <input type="reset" class="btn btn-secondary btnreset" value="Reset" />
                            <input type="submit" name="send" class="btn btn-primary btnsubmit" value="Send" />
                        </form>';
                    }
                ?>            
            </div>
        </div>
    </div>
    
    <footer class="footer">
        <p>&copy; LCP <?php echo date('Y'); ?> - Created by <a href="mailto:carvalholuigi25@gmail.com">Luigi Carvalho</a></p>
    </footer>
    
    <script src="assets/frameworks/bootstrap-5.2.3/js/bootstrap.bundle.min.js"></script>
</body>
</html>